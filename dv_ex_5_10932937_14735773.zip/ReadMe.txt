This exercise was done in a team by:
Elias Bernhaut 14-735-773
Thomas Huber 10-932-937

You can find the finished dashboard with all plots under the following link: https://plot.ly/dashboard/ebernh:22/present

You can also plot all graphs individually by running the files named solutionX.py, where X corresponds to each task.
For this to work, the folder in which the python files are located needs an additional folder ./data in which the uncompressed .list files lie.

Best regards
Thomas & Elias